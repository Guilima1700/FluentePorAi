'use client';

import React, { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, Menu, X } from 'lucide-react';

const LINKS = [
  { id: 'sobre', label: 'Sobre nós' },
  { id: 'cursos', label: 'Cursos' },
  { id: 'metodologia', label: 'Metodologia' },
  { id: 'diferenciais', label: 'Por que estudar conosco' },
  { id: 'contato', label: 'Contato' },
];

export default function Header({ whatsappLink }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState('');
  const buttonRef = useRef(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Marca no menu a seção que está em foco na rolagem
  useEffect(() => {
    const targets = LINKS.map((l) => document.getElementById(l.id)).filter(Boolean);
    if (!targets.length || !('IntersectionObserver' in window)) return undefined;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(e.target.id);
        });
      },
      { rootMargin: '-45% 0px -50% 0px' }
    );
    targets.forEach((t) => io.observe(t));
    return () => io.disconnect();
  }, []);

  // Esc fecha o menu móvel e devolve o foco ao botão
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => {
      if (e.key === 'Escape') {
        setOpen(false);
        buttonRef.current?.focus();
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open]);

  // Fecha o menu ao passar para o layout de computador
  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    const onChange = () => mq.matches && setOpen(false);
    mq.addEventListener?.('change', onChange);
    return () => mq.removeEventListener?.('change', onChange);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 border-b transition-colors duration-300 ${
        scrolled || open
          ? 'border-brand-navy/10 bg-brand-cream/95 backdrop-blur-md'
          : 'border-transparent bg-brand-cream/70 backdrop-blur-sm'
      }`}
    >
      <div className="mx-auto flex h-[4.5rem] max-w-7xl items-center justify-between px-5 sm:px-8">
        <a href="#inicio" className="flex items-center" aria-label="Fluente por Aí, voltar ao início">
          <img
            src="/brand/logo-creme.png"
            alt="Fluente por Aí"
            width="506"
            height="541"
            className="h-[3.4rem] w-auto"
          />
        </a>

        <nav aria-label="Principal" className="hidden items-center gap-1 lg:flex">
          {LINKS.map((l) => (
            <a
              key={l.id}
              href={`#${l.id}`}
              aria-current={active === l.id ? 'true' : undefined}
              className={`rounded-full px-4 py-2 text-[0.95rem] font-semibold transition-colors hover:bg-brand-navy/10 ${
                active === l.id ? 'bg-brand-navy text-brand-cream hover:bg-brand-navy' : 'text-brand-navy'
              }`}
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="group hidden items-center gap-2 rounded-full bg-brand-red px-5 py-2.5 text-[0.95rem] font-bold text-brand-cream transition hover:bg-brand-redDeep active:scale-[0.97] sm:inline-flex"
          >
            Fale conosco
            <ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
            <span className="sr-only">(abre o WhatsApp em nova aba)</span>
          </a>

          <button
            ref={buttonRef}
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="menu-movel"
            aria-label={open ? 'Fechar menu' : 'Abrir menu'}
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-brand-navy/20 text-brand-navy transition hover:bg-brand-navy/10 lg:hidden"
          >
            {open ? <X className="h-5 w-5" aria-hidden="true" /> : <Menu className="h-5 w-5" aria-hidden="true" />}
          </button>
        </div>
      </div>

      {open && (
        <nav
          id="menu-movel"
          aria-label="Menu móvel"
          className="border-t border-brand-navy/10 bg-brand-cream lg:hidden"
        >
          <ul className="mx-auto max-w-7xl px-5 py-4 sm:px-8">
            {LINKS.map((l) => (
              <li key={l.id}>
                <a
                  href={`#${l.id}`}
                  onClick={() => setOpen(false)}
                  className="display flex items-center justify-between border-b border-brand-navy/10 py-4 text-[2rem]"
                >
                  {l.label}
                  <ArrowUpRight className="h-5 w-5 text-brand-red" aria-hidden="true" />
                </a>
              </li>
            ))}
            <li className="pt-5">
              <a
                href={whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setOpen(false)}
                className="flex items-center justify-center gap-2 rounded-full bg-brand-red px-6 py-4 text-base font-bold text-brand-cream active:scale-[0.98]"
              >
                Fale conosco
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                <span className="sr-only">(abre o WhatsApp em nova aba)</span>
              </a>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}
