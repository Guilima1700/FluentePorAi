# Fluente por Aí - Landing Page

Landing page da escola de inglês online **Fluente por Aí** ("English that takes you places.").

## Stack
- **Next.js 14** (App Router) e **React 18**
- **Tailwind CSS** (paleta da marca em `tailwind.config.js`)
- **Framer Motion** (entradas e transições; respeita `prefers-reduced-motion`)
- **Lucide React** (ícones)
- **Canvas 2D** (globo interativo da seção inicial, `components/InteractiveGlobe.jsx`)

## Identidade visual
Cores extraídas dos logos e das peças de feed em `public/`:
céu `#669BBB`, marinho `#01304A`, creme `#FEF0D5`, vermelho `#C1121F`, vinho `#780001`.
Tipografia: Instrument Serif (destaques) e Urbanist (texto), carregadas pelo Google Fonts em `app/layout.jsx`.

Assets derivados: `public/brand/` (logos com fundo transparente e emblema) e `public/photos/` (recortes das peças de feed).

## Conteúdo editável
- Depoimentos: preencha a lista `testimonials` no topo de `app/page.jsx`
  (`{ name, course, quote }`). Enquanto estiver vazia, a página mostra o espaço reservado.
- LinkedIn: adicione o campo `href` ao item "LinkedIn" em `Contact()` quando a URL do perfil for confirmada.

## Como rodar
```bash
npm install
npm run dev      # http://localhost:3000
npm run build && npm run start
```
