'use client';

import React, { useRef } from 'react';
import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  Instagram,
  Linkedin,
  Mail,
  MapPin,
  MessageCircle,
  Quote,
} from 'lucide-react';
import InteractiveGlobe from '../components/InteractiveGlobe';
import Header from '../components/Header';
import {
  Balloon,
  BurstLines,
  ChatBubble,
  Edge,
  Magnifier,
  Pencil,
  Seal,
  Starburst,
} from '../components/Illustrations';

/* ------------------------------------------------------------------ */
/* Dados da marca                                                      */
/* ------------------------------------------------------------------ */

const COLORS = {
  cream: '#FEF0D5',
  paper: '#FFF8EA',
  sky: '#669BBB',
  navy: '#01304A',
  red: '#C1121F',
  wine: '#780001',
};

const WHATSAPP = 'https://wa.me/5592982021077';
const whatsappWith = (message) => `${WHATSAPP}?text=${encodeURIComponent(message)}`;
const INSTAGRAM = 'https://instagram.com/fluenteporai';
const EMAIL = 'fluenteporai@fluenteporai.com';
const YEAR = new Date().getFullYear();

const courses = [
  {
    id: 'geral',
    title: 'Inglês Geral',
    desc: 'Aulas personalizadas para desenvolver compreensão, vocabulário, gramática e conversação.',
    message: 'Olá! Gostaria de saber mais sobre o curso de Inglês Geral.',
    tile: 'bg-brand-red text-brand-cream md:col-span-7 [--focus:#FEF0D5]',
    button: 'bg-brand-cream text-brand-navy hover:bg-brand-paper',
    art: <ChatBubble className="h-24 w-auto sm:h-32" body={COLORS.cream} dots={COLORS.red} />,
  },
  {
    id: 'business',
    title: 'Business English',
    desc: 'Inglês para reuniões, apresentações, negociações, entrevistas e comunicação corporativa.',
    message: 'Olá! Gostaria de saber mais sobre o curso de Business English.',
    tile: 'bg-brand-navy text-brand-cream md:col-span-5 [--focus:#FEF0D5]',
    button: 'bg-brand-cream text-brand-navy hover:bg-brand-paper',
    art: <Pencil className="h-28 w-auto rotate-[24deg] sm:h-36" body={COLORS.red} stripe={COLORS.cream} tip={COLORS.sky} />,
  },
  {
    id: 'travel',
    title: 'English for Travel',
    desc: 'Preparação linguística para viagens, turismo, intercâmbios e experiências internacionais.',
    message: 'Olá! Gostaria de saber mais sobre o curso English for Travel.',
    tile: 'bg-brand-sky text-brand-navy md:col-span-5 [--focus:#01304A]',
    button: 'bg-brand-navy text-brand-cream hover:bg-brand-wine',
    art: <Balloon className="h-28 w-auto sm:h-40" />,
  },
  {
    id: 'corporativo',
    title: 'Treinamento Corporativo',
    desc: 'Para empresas que desejam capacitar suas equipes em inglês.',
    message: 'Olá! Gostaria de saber mais sobre o Treinamento Corporativo.',
    tile: 'bg-brand-wine text-brand-cream md:col-span-7 [--focus:#FEF0D5]',
    button: 'bg-brand-cream text-brand-navy hover:bg-brand-paper',
    art: (
      <Magnifier
        className="h-24 w-auto sm:h-32"
        ring={COLORS.cream}
        glass={COLORS.navy}
        handle={COLORS.red}
        stripeA={COLORS.sky}
        stripeB={COLORS.red}
      />
    ),
  },
];

const pillars = [
  {
    title: 'Abordagem comunicativa',
    desc: 'Aprender inglês utilizando o idioma desde as primeiras aulas.',
    phrase: 'Nice to meet you!',
    card: 'bg-brand-cream text-brand-navy [--focus:#01304A]',
    bubble: 'bg-brand-navy text-brand-cream',
    art: <ChatBubble className="h-16 w-auto md:h-24" />,
  },
  {
    title: 'Aprendizagem contextualizada',
    desc: 'Situações reais do cotidiano e do ambiente profissional.',
    phrase: 'I have a meeting at 3 p.m.',
    card: 'bg-brand-sky text-brand-navy [--focus:#01304A]',
    bubble: 'bg-brand-cream text-brand-navy',
    art: <Magnifier className="h-16 w-auto md:h-24" />,
  },
  {
    title: 'Acompanhamento individualizado',
    desc: 'Conteúdo adaptado ao nível e aos objetivos do aluno.',
    phrase: 'What is your goal?',
    card: 'bg-brand-red text-brand-cream [--focus:#FEF0D5]',
    bubble: 'bg-brand-cream text-brand-navy',
    art: <Pencil className="h-20 w-auto rotate-[20deg] md:h-28" body={COLORS.cream} stripe={COLORS.navy} tip={COLORS.sky} />,
  },
  {
    title: 'Professores qualificados',
    desc: 'Ensino conduzido por profissionais preparados e com experiência.',
    phrase: 'Great! Try it again.',
    card: 'bg-brand-wine text-brand-cream [--focus:#FEF0D5]',
    bubble: 'bg-brand-sky text-brand-navy',
    art: (
      <img
        src="/brand/emblema-marinho.png"
        alt=""
        width="196"
        height="260"
        loading="lazy"
        className="h-16 w-auto md:h-24"
      />
    ),
  },
];

const benefits = [
  'Aulas 100% online',
  'Atendimento personalizado',
  'Programas para diferentes níveis',
  'Inglês para objetivos pessoais e profissionais',
  'Professores qualificados',
  'Flexibilidade de horários',
];

/*
 * Depoimentos: enquanto a lista estiver vazia, a página mostra o espaço reservado.
 * Para publicar, preencha neste formato (não há depoimentos inventados):
 *   { name: 'Nome do aluno', course: 'Curso', quote: 'Texto do depoimento' }
 */
const testimonials = [];

/* ------------------------------------------------------------------ */
/* Utilitários de animação                                             */
/* ------------------------------------------------------------------ */

const EASE = [0.22, 1, 0.36, 1];

function Reveal({ as = 'div', delay = 0, y = 20, className = '', children }) {
  const reduce = useReducedMotion();
  const Tag = motion[as];
  return (
    <Tag
      className={className}
      initial={reduce ? false : { opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '0px 0px -10% 0px' }}
      transition={{ duration: 0.6, delay, ease: EASE }}
    >
      {children}
    </Tag>
  );
}

/* Linha de título que sobe de dentro de uma máscara */
function MaskLine({ children, delay = 0, className = '' }) {
  const reduce = useReducedMotion();
  return (
    <span className="-mb-[0.26em] block overflow-hidden pb-[0.26em]">
      <motion.span
        className={`block ${className}`}
        initial={reduce ? false : { y: '110%' }}
        animate={{ y: 0 }}
        transition={{ duration: 0.85, delay, ease: EASE }}
      >
        {children}
      </motion.span>
    </span>
  );
}

function Button({ href, variant = 'primary', external = false, children, className = '' }) {
  const styles = {
    primary: 'bg-brand-red text-brand-cream hover:bg-brand-redDeep',
    outline: 'border-2 border-brand-navy text-brand-navy hover:bg-brand-navy hover:text-brand-cream',
    cream: 'bg-brand-cream text-brand-navy hover:bg-brand-paper',
    outlineCream: 'border-2 border-brand-cream text-brand-cream hover:bg-brand-cream hover:text-brand-navy',
  };
  const extra = external ? { target: '_blank', rel: 'noopener noreferrer' } : {};
  return (
    <a
      href={href}
      {...extra}
      className={`group inline-flex items-center justify-center gap-2.5 rounded-full px-7 py-4 text-base font-bold transition duration-200 active:scale-[0.97] ${styles[variant]} ${className}`}
    >
      {children}
      {external ? (
        <>
          <ArrowUpRight className="h-[1.1rem] w-[1.1rem] transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
          <span className="sr-only">(abre em nova aba)</span>
        </>
      ) : (
        <ArrowRight className="h-[1.1rem] w-[1.1rem] transition-transform duration-200 group-hover:translate-x-1" aria-hidden="true" />
      )}
    </a>
  );
}

/* ------------------------------------------------------------------ */
/* Seções                                                              */
/* ------------------------------------------------------------------ */

function Hero() {
  const reduce = useReducedMotion();
  return (
    <section id="inicio" className="relative scroll-mt-20">
      <div className="mx-auto grid max-w-7xl items-center gap-10 px-5 pb-28 pt-8 sm:px-8 lg:grid-cols-12 lg:gap-2 lg:pb-40 lg:pt-12">
        <div className="relative z-10 lg:col-span-7">
          <h1 className="text-brand-navy">
            <MaskLine className="font-sans text-[clamp(2.9rem,7.2vw,6.6rem)] font-light leading-[1] tracking-tight">
              English that
            </MaskLine>
            <MaskLine delay={0.12} className="display text-[clamp(4rem,11.5vw,10rem)] italic leading-[0.86] text-brand-red">
              takes you
            </MaskLine>
            <MaskLine delay={0.24} className="display text-[clamp(4rem,11.5vw,10rem)] italic leading-[0.86] text-brand-red">
              places.
            </MaskLine>
          </h1>

          <Reveal delay={0.45} className="mt-8 max-w-xl">
            <p className="text-[1.2rem] font-medium leading-relaxed text-brand-navy sm:text-[1.3rem]">
              Aprenda inglês para se comunicar com confiança, desenvolver sua carreira e explorar novas oportunidades
              pelo mundo. Na Fluente por Aí, você encontra aulas online, programas personalizados e experiências de
              aprendizagem focadas na comunicação real.
            </p>
          </Reveal>

          <Reveal delay={0.6} className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Button href="#cursos" variant="primary">
              Conheça nossos cursos
            </Button>
            <Button href={WHATSAPP} variant="outline" external>
              Fale conosco
            </Button>
          </Reveal>
        </div>

        <motion.div
          className="relative mx-auto w-full max-w-[34rem] lg:col-span-5 lg:max-w-none"
          initial={reduce ? false : { opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.25, ease: EASE }}
        >
          <InteractiveGlobe />

          <span className="absolute left-0 top-[8%] -rotate-6 rounded-lg bg-brand-wine px-4 py-2 font-sans text-base font-bold text-brand-cream shadow-[0_6px_0_rgba(1,48,74,0.18)] sm:left-2">
            Aulas 100% online
          </span>
          <span className="absolute bottom-[10%] right-0 rotate-[4deg] rounded-lg bg-brand-sky px-4 py-2 font-sans text-base font-bold text-brand-navy shadow-[0_6px_0_rgba(1,48,74,0.18)] sm:right-2">
            Programas personalizados
          </span>

          <div className="absolute -bottom-3 left-0 h-28 w-28 sm:left-4 sm:h-32 sm:w-32">
            <Seal className="animate-spin-slow h-full w-full" />
            <Starburst className="absolute inset-0 m-auto h-9 w-9" />
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function Ribbon() {
  const phrase = 'English that takes you places.';
  const group = (
    <div className="flex shrink-0 items-center gap-8 pr-8">
      {Array.from({ length: 6 }).map((_, i) => (
        <React.Fragment key={i}>
          <span className="display whitespace-nowrap text-[2rem] italic leading-none">{phrase}</span>
          <Starburst className="h-6 w-6 shrink-0" fill={COLORS.cream} />
        </React.Fragment>
      ))}
    </div>
  );
  return (
    <div
      aria-hidden="true"
      className="relative z-20 -mx-4 -mb-9 -mt-9 w-[calc(100%+2rem)] -rotate-[1.6deg] overflow-hidden bg-brand-red py-4 text-brand-cream"
    >
      <div className="animate-marquee flex w-max">
        {group}
        {group}
      </div>
    </div>
  );
}

function About() {
  const ref = useRef(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  const xTop = useTransform(scrollYProgress, [0, 1], ['2%', '-22%']);
  const xBottom = useTransform(scrollYProgress, [0, 1], ['-40%', '-5%']);
  const ghost = 'fluente por aí  fluente por aí  fluente por aí  fluente por aí';

  return (
    <section id="sobre" ref={ref} className="relative scroll-mt-20 overflow-hidden bg-brand-sky text-brand-navy [--focus:#01304A]">
      {/* Texto fantasma que desliza com a rolagem */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-[4.5rem] select-none">
        <motion.p style={reduce ? undefined : { x: xTop }} className="display whitespace-nowrap text-[clamp(5rem,15vw,13rem)] italic text-brand-cream/30">
          {ghost}
        </motion.p>
      </div>
      <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 bottom-6 select-none">
        <motion.p style={reduce ? undefined : { x: xBottom }} className="display whitespace-nowrap text-[clamp(5rem,15vw,13rem)] italic text-brand-cream/30">
          {ghost}
        </motion.p>
      </div>

      <div className="relative mx-auto grid max-w-7xl gap-16 px-5 pb-28 pt-40 sm:px-8 sm:pb-32 lg:grid-cols-12 lg:items-center lg:gap-10 lg:pt-44">
        <div className="lg:col-span-6">
          <Reveal as="h2" className="display text-[clamp(3.6rem,8.5vw,7.5rem)]">
            Sobre nós
          </Reveal>
          <Reveal delay={0.1} className="mt-8 max-w-xl space-y-5 text-[1.2rem] font-medium leading-relaxed">
            <p>
              A Fluente por Aí nasceu com o propósito de tornar o aprendizado de inglês mais acessível, prático e
              conectado aos objetivos de cada aluno. Acreditamos que aprender um idioma vai além de estudar gramática:
              é desenvolver habilidades para se comunicar, trabalhar, viajar e aproveitar oportunidades internacionais.
            </p>
          </Reveal>
          <Reveal delay={0.2} className="mt-8 max-w-xl rounded-[1.75rem] bg-brand-paper p-7 shadow-[0_8px_0_rgba(1,48,74,0.16)]">
            <p className="text-[1.15rem] font-semibold leading-relaxed">
              Nossa abordagem combina metodologia comunicativa, conteúdos contextualizados e acompanhamento do
              desenvolvimento dos alunos.
            </p>
          </Reveal>
        </div>

        <div className="relative mx-auto h-[34rem] w-full max-w-[34rem] sm:h-[38rem] lg:col-span-6">
          <motion.div
            className="absolute left-0 top-6 w-[58%] overflow-hidden rounded-t-full border-[6px] border-brand-cream bg-brand-cream shadow-[0_10px_0_rgba(1,48,74,0.16)]"
            initial={reduce ? false : { opacity: 0, y: 40, rotate: -3 }}
            whileInView={{ opacity: 1, y: 0, rotate: 0 }}
            viewport={{ once: true, margin: '0px 0px -10% 0px' }}
            transition={{ duration: 0.8, ease: EASE }}
          >
            <img
              src="/photos/viajante-mapa.jpg"
              alt="Viajante de costas, com mochila e chapéu, lendo um mapa em uma estrada"
              width="534"
              height="610"
              loading="lazy"
              decoding="async"
              className="aspect-[3/4.2] w-full object-cover"
            />
          </motion.div>

          <motion.div
            className="absolute bottom-0 right-0 w-[56%] rotate-[4deg] overflow-hidden rounded-[1.5rem] border-[6px] border-brand-paper bg-brand-paper shadow-[0_10px_0_rgba(1,48,74,0.16)]"
            initial={reduce ? false : { opacity: 0, y: 40, rotate: 10 }}
            whileInView={{ opacity: 1, y: 0, rotate: 4 }}
            viewport={{ once: true, margin: '0px 0px -10% 0px' }}
            transition={{ duration: 0.8, delay: 0.15, ease: EASE }}
          >
            <img
              src="/photos/viajante-camera.jpg"
              alt="Viajante com mochila fotografando um prédio histórico com o celular"
              width="548"
              height="733"
              loading="lazy"
              decoding="async"
              className="aspect-[1/1.1] w-full object-cover"
            />
          </motion.div>

          <motion.div
            className="absolute -top-2 right-2 sm:right-8"
            animate={reduce ? undefined : { y: [0, -12, 0] }}
            transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut' }}
          >
            <Balloon className="h-32 w-auto sm:h-40" />
          </motion.div>
          <Starburst className="animate-spin-slow absolute bottom-24 left-2 h-20 w-20" />
          <Pencil className="absolute bottom-2 left-[18%] h-28 w-auto -rotate-[28deg]" />
        </div>
      </div>
    </section>
  );
}

function Courses() {
  const reduce = useReducedMotion();
  return (
    <section id="cursos" className="relative scroll-mt-20 py-24 sm:py-32">
      <Edge color={COLORS.sky} />
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-6 lg:grid-cols-12 lg:items-end">
          <Reveal as="h2" className="display text-[clamp(3.2rem,7.5vw,6.5rem)] lg:col-span-7">
            Cursos e serviços
          </Reveal>
          <Reveal delay={0.1} className="lg:col-span-5">
            <p className="max-w-md text-[1.2rem] font-medium leading-relaxed">
              Escolha o programa que combina com o seu objetivo, pessoal ou profissional.
            </p>
          </Reveal>
        </div>

        <ul className="mt-14 grid grid-cols-1 gap-5 md:grid-cols-12">
          {courses.map((c, i) => (
            <motion.li
              key={c.id}
              className={`group relative flex min-h-[23rem] flex-col justify-between overflow-hidden rounded-[2rem] p-8 transition-transform duration-300 hover:-translate-y-1 sm:p-10 ${c.tile}`}
              initial={reduce ? false : { opacity: 0, y: 44, scale: 0.97 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: true, margin: '0px 0px -8% 0px' }}
              transition={{ duration: 0.7, delay: (i % 2) * 0.1, ease: EASE }}
            >
              <div className="flex justify-end transition-transform duration-500 ease-out group-hover:-rotate-6 group-hover:scale-105">
                {c.art}
              </div>
              <div className="mt-10">
                <h3 className="display text-[clamp(2.4rem,4.4vw,3.8rem)]">{c.title}</h3>
                <p className="mt-4 max-w-md text-[1.1rem] font-medium leading-relaxed">{c.desc}</p>
                <a
                  href={whatsappWith(c.message)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`group/btn mt-7 inline-flex items-center gap-2 rounded-full px-6 py-3 text-[0.95rem] font-bold transition duration-200 active:scale-[0.97] ${c.button}`}
                >
                  Quero saber mais
                  <ArrowUpRight className="h-4 w-4 transition-transform duration-200 group-hover/btn:-translate-y-0.5 group-hover/btn:translate-x-0.5" aria-hidden="true" />
                  <span className="sr-only">sobre {c.title} (abre o WhatsApp em nova aba)</span>
                </a>
              </div>
            </motion.li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function Method() {
  return (
    <section id="metodologia" className="relative scroll-mt-20 bg-brand-navy py-24 text-brand-cream [--focus:#FEF0D5] sm:py-32">
      <Edge color={COLORS.cream} />
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-6 lg:grid-cols-12 lg:items-end">
          <Reveal as="h2" className="display text-[clamp(3.2rem,7.5vw,6.5rem)] lg:col-span-7">
            Metodologia
          </Reveal>
          <Reveal delay={0.1} className="lg:col-span-5">
            <p className="max-w-md text-[1.2rem] font-medium leading-relaxed text-brand-cream">
              Quatro pilares para você usar o inglês de verdade, em situações que fazem sentido na sua vida.
            </p>
          </Reveal>
        </div>

        {/* Os cartões se empilham ao rolar */}
        <ol className="relative mt-14 pb-4">
          {pillars.map((p, i) => (
            <li
              key={p.title}
              className="sticky mb-6"
              style={{ top: `calc(5.75rem + ${i * 1.1}rem)` }}
            >
              <div className={`grid items-center gap-6 rounded-[2rem] p-7 shadow-[0_-10px_30px_rgba(1,48,74,0.35)] sm:p-10 md:min-h-[17rem] md:grid-cols-12 md:gap-8 ${p.card}`}>
                <div className="flex md:col-span-2 md:justify-center" aria-hidden="true">
                  {p.art}
                </div>
                <div className="md:col-span-6">
                  <h3 className="display text-[clamp(2.1rem,4.2vw,3.4rem)]">{p.title}</h3>
                  <p className="mt-3 max-w-md text-[1.1rem] font-medium leading-relaxed">{p.desc}</p>
                </div>
                <div className="flex md:col-span-4 md:justify-end" aria-hidden="true">
                  <p lang="en" className={`rounded-[1.5rem] rounded-bl-md px-6 py-4 text-lg font-bold ${p.bubble}`}>
                    {p.phrase}
                  </p>
                </div>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

function Benefits() {
  const reduce = useReducedMotion();
  return (
    <section id="diferenciais" className="relative scroll-mt-20 py-24 sm:py-32">
      <Edge color={COLORS.navy} />
      <div className="mx-auto grid max-w-7xl gap-14 px-5 sm:px-8 lg:grid-cols-12 lg:gap-16">
        <div className="self-start lg:sticky lg:top-28 lg:col-span-5">
          <Reveal as="h2" className="display text-[clamp(3.2rem,6.4vw,5.6rem)]">
            Por que estudar conosco?
          </Reveal>
          <motion.div
            className="relative mt-10 w-full max-w-sm"
            initial={reduce ? false : { opacity: 0, y: 36 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '0px 0px -10% 0px' }}
            transition={{ duration: 0.8, ease: EASE }}
          >
            <img
              src="/photos/estudante.jpg"
              alt="Estudante sorrindo, com cadernos nos braços, em frente a colegas"
              width="517"
              height="592"
              loading="lazy"
              decoding="async"
              className="aspect-[4/5] w-full rounded-t-full rounded-b-[2rem] border-[6px] border-brand-paper object-cover shadow-[0_10px_0_rgba(1,48,74,0.14)]"
            />
            <div className="absolute -right-4 bottom-8 h-24 w-24 sm:-right-8 sm:h-28 sm:w-28">
              <Starburst className="animate-spin-slow h-full w-full" />
              <Check className="absolute inset-0 m-auto h-9 w-9 text-brand-cream" strokeWidth={3} aria-hidden="true" />
            </div>
          </motion.div>
        </div>

        <ul className="lg:col-span-7 lg:pt-6">
          {benefits.map((text, i) => (
            <motion.li
              key={text}
              className="group relative flex items-center gap-5 py-6 sm:gap-6 sm:py-8"
              initial={reduce ? false : { opacity: 0, x: -18 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '0px 0px -8% 0px' }}
              transition={{ duration: 0.55, delay: 0.04, ease: EASE }}
            >
              <motion.span
                aria-hidden="true"
                className="absolute inset-x-0 bottom-0 h-0.5 origin-left bg-brand-navy/25"
                initial={reduce ? false : { scaleX: 0 }}
                whileInView={{ scaleX: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.9, delay: 0.1, ease: EASE }}
              />
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-brand-red text-brand-cream transition-transform duration-300 group-hover:rotate-[-12deg] group-hover:scale-110 sm:h-14 sm:w-14">
                <Check className="h-6 w-6" strokeWidth={3} aria-hidden="true" />
              </span>
              <span className="display text-[clamp(1.9rem,3.6vw,3rem)] leading-[1.02] transition-transform duration-300 group-hover:translate-x-1">
                {text}
              </span>
            </motion.li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function Testimonials() {
  const hasItems = testimonials.length > 0;
  return (
    <section id="depoimentos" className="relative scroll-mt-20 bg-brand-paper py-24 sm:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-6 lg:grid-cols-12 lg:items-end">
          <Reveal as="h2" className="display text-[clamp(3rem,6.5vw,5.5rem)] lg:col-span-7">
            Depoimentos
          </Reveal>
          <Reveal delay={0.1} className="lg:col-span-5">
            <p className="max-w-md text-[1.15rem] font-medium leading-relaxed">
              {hasItems
                ? 'Quem aprende com a Fluente por Aí conta como foi.'
                : 'Em breve, você vai ler aqui o que os nossos alunos têm a dizer.'}
            </p>
          </Reveal>
        </div>

        <ul className="mt-12 grid gap-5 md:grid-cols-3">
          {hasItems
            ? testimonials.map((t, i) => (
                <Reveal as="li" key={`${t.name}-${i}`} delay={i * 0.08} className="flex flex-col justify-between rounded-[1.75rem] bg-brand-cream p-8">
                  <figure>
                    <Quote className="h-8 w-8 text-brand-red" aria-hidden="true" />
                    <blockquote className="mt-4 text-[1.15rem] font-medium leading-relaxed">{t.quote}</blockquote>
                    <figcaption className="mt-6 font-bold">
                      {t.name}
                      {t.course ? <span className="block text-base font-medium text-brand-navy/80">{t.course}</span> : null}
                    </figcaption>
                  </figure>
                </Reveal>
              ))
            : [0, 1, 2].map((i) => (
                <Reveal as="li" key={i} delay={i * 0.08} className="flex min-h-[15rem] flex-col justify-between rounded-[1.75rem] border-2 border-dashed border-brand-navy/35 p-8">
                  <span className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-red text-brand-cream">
                    <Quote className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <div>
                    <p className="display text-[2rem]">Depoimento em breve</p>
                    <p className="mt-2 text-base font-medium text-brand-navy/80">Espaço reservado para a fala de um aluno.</p>
                  </div>
                </Reveal>
              ))}
        </ul>
      </div>
    </section>
  );
}

function Contact() {
  const channels = [
    {
      icon: MessageCircle,
      label: 'WhatsApp',
      value: '+55 92 98202-1077',
      href: WHATSAPP,
      external: true,
    },
    {
      icon: Instagram,
      label: 'Instagram',
      value: '@fluenteporai',
      href: INSTAGRAM,
      external: true,
    },
    {
      icon: Mail,
      label: 'E-mail comercial',
      value: EMAIL,
      href: `mailto:${EMAIL}`,
    },
    // O endereço do perfil no LinkedIn não consta nos arquivos do projeto: exibimos só o nome.
    {
      icon: Linkedin,
      label: 'LinkedIn',
      value: 'fluenteporai',
    },
    {
      icon: MapPin,
      label: 'Localização',
      value: 'Manaus/AM',
    },
  ];

  return (
    <section id="contato" className="relative scroll-mt-20 overflow-hidden bg-brand-red py-24 text-brand-cream [--focus:#FEF0D5] sm:py-32">
      <Edge color={COLORS.paper} />
      <div aria-hidden="true" className="pointer-events-none absolute -right-40 -top-40 h-[38rem] w-[38rem] opacity-[0.13]">
        <Starburst className="animate-spin-slow h-full w-full" fill={COLORS.cream} points={20} inner={0.7} />
      </div>
      <div aria-hidden="true" className="pointer-events-none absolute -bottom-24 -left-24 h-72 w-72 opacity-30">
        <BurstLines className="animate-spin-slow h-full w-full" stroke={COLORS.cream} />
      </div>

      <div className="relative mx-auto grid max-w-7xl gap-14 px-5 sm:px-8 lg:grid-cols-12 lg:items-center">
        <div className="lg:col-span-7">
          <Reveal as="h2" className="display text-[clamp(3.6rem,9.5vw,8.5rem)]">
            Ready to learn English?
          </Reveal>
          <Reveal delay={0.1} className="mt-8 max-w-lg">
            <p className="text-[1.5rem] font-medium leading-snug sm:text-[1.7rem]">
              Dê o próximo passo no seu aprendizado de inglês.
            </p>
          </Reveal>
          <Reveal delay={0.2} className="mt-10 flex flex-col gap-3 sm:flex-row">
            <Button href={WHATSAPP} variant="cream" external>
              Chamar no WhatsApp
            </Button>
            <Button href={INSTAGRAM} variant="outlineCream" external>
              Ver o Instagram
            </Button>
          </Reveal>
        </div>

        <Reveal delay={0.15} className="lg:col-span-5">
          <ul className="rounded-[2rem] bg-brand-paper p-3 text-brand-navy shadow-[0_12px_0_rgba(120,0,1,0.45)] [--focus:#01304A]">
            {channels.map(({ icon: Icon, label, value, href, external }) => {
              const inner = (
                <>
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-brand-navy text-brand-cream">
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-bold text-brand-navy/75">{label}</span>
                    <span className="block break-words text-[1.05rem] font-bold leading-snug sm:text-lg">{value}</span>
                  </span>
                  {href ? (
                    <ArrowUpRight className="h-5 w-5 shrink-0 text-brand-red transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
                  ) : null}
                </>
              );
              return (
                <li key={label}>
                  {href ? (
                    <a
                      href={href}
                      {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                      className="group flex items-center gap-4 rounded-[1.4rem] p-4 transition-colors hover:bg-brand-cream"
                    >
                      {inner}
                      {external ? <span className="sr-only">(abre em nova aba)</span> : null}
                    </a>
                  ) : (
                    <div className="flex items-center gap-4 rounded-[1.4rem] p-4">{inner}</div>
                  )}
                </li>
              );
            })}
          </ul>
        </Reveal>
      </div>
    </section>
  );
}

function Footer() {
  const nav = [
    { href: '#sobre', label: 'Sobre nós' },
    { href: '#cursos', label: 'Cursos' },
    { href: '#metodologia', label: 'Metodologia' },
    { href: '#diferenciais', label: 'Por que estudar conosco' },
    { href: '#contato', label: 'Contato' },
  ];
  return (
    <footer className="relative bg-brand-navy text-brand-cream [--focus:#FEF0D5]">
      <Edge color={COLORS.red} />
      <div className="mx-auto grid max-w-7xl gap-10 px-5 pb-10 pt-20 sm:px-8 md:grid-cols-12 md:items-center">
        <div className="flex items-center gap-6 md:col-span-6">
          <img src="/brand/logo-marinho.png" alt="Fluente por Aí" width="506" height="541" loading="lazy" className="h-28 w-auto" />
          <p className="display text-[2.2rem] italic leading-[1]">English that takes you places.</p>
        </div>
        <nav aria-label="Rodapé" className="md:col-span-6 md:justify-self-end">
          <ul className="flex flex-wrap gap-x-6 gap-y-2 font-semibold">
            {nav.map((n) => (
              <li key={n.href}>
                <a href={n.href} className="underline-offset-4 hover:underline">
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </div>
      <div className="mx-auto max-w-7xl px-5 pb-8 sm:px-8">
        <p className="border-t border-brand-cream/20 pt-6 text-sm font-medium">
          © {YEAR} Fluente por Aí. Todos os direitos reservados.
        </p>
      </div>
    </footer>
  );
}

export default function FluentePorAiLanding() {
  return (
    <div className="min-h-screen overflow-x-clip bg-brand-cream font-sans text-brand-navy">
      <a href="#conteudo" className="skip-link">
        Ir para o conteúdo
      </a>
      <Header whatsappLink={WHATSAPP} />
      <main id="conteudo">
        <Hero />
        <Ribbon />
        <About />
        <Courses />
        <Method />
        <Benefits />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
